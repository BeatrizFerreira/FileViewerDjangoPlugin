import django
from django.test import TestCase