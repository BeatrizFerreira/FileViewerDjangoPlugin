=====
FileViewer
====

This is a Django plugin to render files like pdf, ebooks and others.

Quick start
-------------
1) Add "fileviewer" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'polls',
    ]

There is no need to kmake migrations or include urls.